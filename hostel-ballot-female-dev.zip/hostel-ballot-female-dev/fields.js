
module.exports =  {
    LOGIN_USERNAME_ID: '#UsernameTextBox',
    LOGIN_PASSWORD_ID: '#PasswordTextBox',
    BUTTON_SELECTOR: 'input[type=submit]',
    BALLOT_DIV_ENTRY: 'accommodationdiv a',
    BALLOT_REQUEST_TAG: 'hallslist li:nth-child(3) a',
    BALLOT_SUBMIT_BUTTON: '#Contents_SubmitButton',
    ERROR_DIV: '#errordiv'
};